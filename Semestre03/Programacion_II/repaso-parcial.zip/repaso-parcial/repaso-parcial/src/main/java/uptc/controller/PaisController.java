package uptc.controller;

import java.util.List;
import javax.swing.table.DefaultTableModel;
import uptc.dao.PaisDao;
import uptc.model.PaisModel;

public class PaisController {

    private PaisDao paisDao;
    private String ruta = "File/persistencia.xml";

    public PaisController() {
        this.paisDao = new PaisDao(ruta);
    }
    
    public void cargarDepartamentosEnTabla(DefaultTableModel modeloTabla, String nombrePaisBuscado) {
        
        modeloTabla.setRowCount(0);

        List<PaisModel> listaPaises = paisDao.obtenerPaises();

        for (PaisModel pais : listaPaises) {
            if (pais.getNombre().equalsIgnoreCase(nombrePaisBuscado)) {
                
                for (String depto : pais.getDepartamentos()) {
                    Object[] fila = { depto };
                    modeloTabla.addRow(fila);
                }
                break; 
            }
        }
    }
}