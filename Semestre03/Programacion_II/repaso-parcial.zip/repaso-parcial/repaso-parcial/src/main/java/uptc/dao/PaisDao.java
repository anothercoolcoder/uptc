package uptc.dao;

import uptc.model.PaisModel;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.DocumentBuilder;
import org.w3c.dom.*;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class PaisDao {
    private String rutaArchivo;

    public PaisDao(String ruta) {
        this.rutaArchivo = ruta;
    }

    public List<PaisModel> obtenerPaises() {
        System.out.println("Buscando en: " + new File(rutaArchivo).getAbsolutePath());
        List<PaisModel> listaPaises = new ArrayList<>();
        try {
            File archivo = new File(rutaArchivo);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(archivo);
            doc.getDocumentElement().normalize();

            NodeList nList = doc.getElementsByTagName("pais");

            for (int i = 0; i < nList.getLength(); i++) {
                Node nNode = nList.item(i);
                if (nNode.getNodeType() == Node.ELEMENT_NODE) {
                    Element e = (Element) nNode;
                    
                    int id = Integer.parseInt(e.getAttribute("id"));
                    String nombre = e.getElementsByTagName("nombre").item(0).getTextContent();
                    
                    List<String> depts = new ArrayList<>();
                    NodeList dList = e.getElementsByTagName("departamento");
                    for (int j = 0; j < dList.getLength(); j++) {
                        depts.add(dList.item(j).getTextContent());
                    }
                    
                    listaPaises.add(new PaisModel(id, nombre, depts));
                }
            }
        } catch (Exception e) {
            System.out.println("Error al leer XML: " + e.getMessage());
        }
        return listaPaises;
    }
}