package logic.exceptions;

public class InvalidFlightSelectionException extends Exception {
    public InvalidFlightSelectionException(String message) {
        super(message);
    }
}
