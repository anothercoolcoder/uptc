package model;

public interface Downloadable {
    String descargar();
}
