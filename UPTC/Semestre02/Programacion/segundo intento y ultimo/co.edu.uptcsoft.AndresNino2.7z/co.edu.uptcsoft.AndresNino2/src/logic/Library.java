package logic;

import model.Content;

import java.util.ArrayList;

public class Library {
    ArrayList<Content> contents = new ArrayList<>();

}
