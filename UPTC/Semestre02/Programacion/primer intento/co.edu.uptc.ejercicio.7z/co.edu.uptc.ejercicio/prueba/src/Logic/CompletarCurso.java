package Logic;

public interface CompletarCurso {
    String completarCurso(Curso curso);
}
