package Test;

import Gui.GuiGestionClase;

public class Main {
    public static void main(String[] args) {
        GuiGestionClase gui = new GuiGestionClase();
        gui.mostrarMenuPrincipal();
    }
}
